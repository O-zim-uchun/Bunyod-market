import logging
import re

logger = logging.getLogger(__name__)

CATEGORY_PREFIX = {
    'tv': 'TV',
    'washing': 'WM',
    'fridge': 'FR',
    'konditsioner': 'AC',
}


def category_to_prefix(category: str) -> str:
    normalized = re.sub(r'\s+', '', category.lower())
    return CATEGORY_PREFIX.get(normalized, category[:2].upper() if category else 'PR')
