from aiogram.exceptions import TelegramBadRequest
from aiogram.types import Message


async def safe_answer_photo(message: Message, photo: str, caption: str, **kwargs) -> None:
    try:
        await message.answer_photo(photo=photo, caption=caption, **kwargs)
    except TelegramBadRequest as exc:
        if 'wrong file identifier/HTTP URL specified' in str(exc):
            await message.answer(caption, **kwargs)
            return
        raise
