from aiogram.fsm.state import State, StatesGroup


class AddProductState(StatesGroup):
    waiting_post = State()
    waiting_video_or_skip = State()


class EditProductState(StatesGroup):
    waiting_post = State()
    waiting_video_or_skip = State()


class SoldProductState(StatesGroup):
    waiting_price = State()
    waiting_note = State()


class BroadcastState(StatesGroup):
    waiting_message = State()


class SoldSearchState(StatesGroup):
    waiting_query = State()


class SettingsPostState(StatesGroup):
    waiting_promo_post = State()
    waiting_contact_post = State()


class RestoreState(StatesGroup):
    waiting_file = State()
