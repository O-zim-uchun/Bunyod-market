from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

BACK_TEXT = '⬅️ Back'


def admin_main_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='➕ Yangi tovar qo‘shish'), KeyboardButton(text='📦 Ombor')],
            [KeyboardButton(text='📊 Statistika'), KeyboardButton(text='💵 Sotilganlar')],
            [KeyboardButton(text='📤Mijozga xabar'), KeyboardButton(text='⚙️Sozlash')],
            [KeyboardButton(text='💾 Backup olish'), KeyboardButton(text='♻️ Restore qilish')],
            [KeyboardButton(text='❌Bekor qilish')],
        ],
        resize_keyboard=True,
    )


def client_main_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='🛍 Tovarlar'), KeyboardButton(text='🔥 Yangi kelganlar')],
            [KeyboardButton(text='💰 Aksiya'), KeyboardButton(text='📞 Aloqa')],
            [KeyboardButton(text='❤️ Sevimlilar ro‘yxati')],
        ],
        resize_keyboard=True,
    )


def back_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=BACK_TEXT)]], resize_keyboard=True)


def product_list_keyboard(product_ids: list[int], names: list[str], page: int, has_prev: bool, has_next: bool, prefix: str) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=name, callback_data=f'{prefix}:view:{pid}')] for pid, name in zip(product_ids, names, strict=True)]
    nav = []
    if has_prev:
        nav.append(InlineKeyboardButton(text='⬅️ Oldingi', callback_data=f'page_{page-1}'))
    if has_next:
        nav.append(InlineKeyboardButton(text='➡️ Keyingi', callback_data=f'page_{page+1}'))
    if nav:
        rows.append(nav)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def no_video_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Yo'q", callback_data=f'{prefix}:no')]])


def product_admin_actions(product_id: int, has_video: bool) -> InlineKeyboardMarkup:
    rows = []
    if has_video:
        rows.append([InlineKeyboardButton(text='Video malumot', callback_data=f'admin_video:{product_id}')])
    rows.extend(
        [
            [InlineKeyboardButton(text='Tahrirlash', callback_data=f'admin_edit:{product_id}')],
            [InlineKeyboardButton(text='Sotildi', callback_data=f'admin_sold:{product_id}')],
            [InlineKeyboardButton(text="Tovarni o'chirish", callback_data=f'admin_delete:{product_id}')],
        ],
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def product_client_actions(product_id: int, has_video: bool) -> InlineKeyboardMarkup:
    rows = []
    if has_video:
        rows.append([InlineKeyboardButton(text='Video malumot', callback_data=f'client_video:{product_id}')])
    rows.append([InlineKeyboardButton(text='❤️ Sevimlilar ro‘yxatiga', callback_data=f'fav_add:{product_id}')])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def sold_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="Ro'yxatni yuklash"), KeyboardButton(text='Izlash')], [KeyboardButton(text=BACK_TEXT)]],
        resize_keyboard=True,
    )


def sold_skip_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="O'tkazib yuborish", callback_data='sold_skip')]])


def settings_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text='💰 Aksiya'), KeyboardButton(text='📞Aloqa')], [KeyboardButton(text=BACK_TEXT)]],
        resize_keyboard=True,
    )


def sold_search_pick_keyboard(ids: list[int], names: list[str]) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=name, callback_data=f'sold_pick:{sid}')] for sid, name in zip(ids, names, strict=True)]
    return InlineKeyboardMarkup(inline_keyboard=rows)
