import asyncio
import logging
from datetime import datetime, timedelta, timezone
from contextlib import asynccontextmanager, suppress

import uvicorn
from aiogram.types import Update
from fastapi import FastAPI, Header, HTTPException, Request

from app.bot_admin.bot import admin_bot, admin_dp
from app.bot_client.bot import client_bot, client_dp
from app.config import get_settings
from app.database.init_db import init_db
from app.database.session import AsyncSessionLocal
from app.services.backup_service import BackupService
from app.services.product_service import ProductService
from app.services.sold_report_service import SoldReportService
from aiogram.types import FSInputFile

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger = logging.getLogger(__name__)
settings = get_settings()


auto_backup_task: asyncio.Task | None = None
monthly_sold_cleanup_task: asyncio.Task | None = None


async def _auto_backup_loop() -> None:
    while True:
        try:
            async with AsyncSessionLocal() as session:
                path = await BackupService(session).export_json()
                logger.info('Auto backup created: %s', path)
        except Exception as exc:  # noqa: BLE001
            logger.exception('Auto backup error: %s', exc)
        await asyncio.sleep(7 * 24 * 60 * 60)


def _seconds_until_next_month_start() -> float:
    now = datetime.now(timezone.utc)
    if now.month == 12:
        nxt = datetime(now.year + 1, 1, 1, tzinfo=timezone.utc)
    else:
        nxt = datetime(now.year, now.month + 1, 1, tzinfo=timezone.utc)
    return max((nxt - now).total_seconds(), 1)


async def _monthly_sold_cleanup_loop() -> None:
    while True:
        await asyncio.sleep(_seconds_until_next_month_start())
        run_time = datetime.now(timezone.utc)
        report_month_end = run_time - timedelta(days=1)
        report_year, report_month = report_month_end.year, report_month_end.month
        try:
            async with AsyncSessionLocal() as session:
                service = SoldReportService(session)
                report_file = await service.build_monthly_report(report_year, report_month)
                if report_file:
                    await admin_bot.send_document(
                        chat_id=settings.admin_id,
                        document=FSInputFile(report_file.as_posix()),
                        caption=f"{report_year:04d}-{report_month:02d} oyi uchun sotilganlar hisoboti",
                    )
                await ProductService(session).clear_sold_items()

            await admin_bot.send_message(
                chat_id=settings.admin_id,
                text="Sotilganlar ro'yxati tozalandi. Oylik hisobot yuborildi.",
            )
            logger.info('Monthly sold items cleanup completed for %04d-%02d', report_year, report_month)
        except Exception as exc:  # noqa: BLE001
            logger.exception('Monthly sold items cleanup error: %s', exc)


@asynccontextmanager
async def lifespan(_: FastAPI):
    global auto_backup_task, monthly_sold_cleanup_task

    await init_db()
    admin_dp['client_bot'] = client_bot

    await admin_bot.set_webhook(
        url=f"{settings.webhook_base_url}/webhook/admin",
        secret_token=settings.webhook_secret,
        drop_pending_updates=True,
    )
    await client_bot.set_webhook(
        url=f"{settings.webhook_base_url}/webhook/client",
        secret_token=settings.webhook_secret,
        drop_pending_updates=True,
    )

    auto_backup_task = asyncio.create_task(_auto_backup_loop())
    monthly_sold_cleanup_task = asyncio.create_task(_monthly_sold_cleanup_loop())
    logger.info('Webhooks registered')

    try:
        yield
    finally:
        if auto_backup_task:
            auto_backup_task.cancel()
            with suppress(asyncio.CancelledError):
                await auto_backup_task
        if monthly_sold_cleanup_task:
            monthly_sold_cleanup_task.cancel()
            with suppress(asyncio.CancelledError):
                await monthly_sold_cleanup_task
        await admin_bot.delete_webhook()
        await client_bot.delete_webhook()
        await admin_bot.session.close()
        await client_bot.session.close()


app = FastAPI(title='Elite Bot Webhook Server', lifespan=lifespan)


@app.post('/webhook/admin')
async def admin_webhook(request: Request, x_telegram_bot_api_secret_token: str = Header(default='')) -> dict[str, bool]:
    if x_telegram_bot_api_secret_token != settings.webhook_secret:
        raise HTTPException(status_code=403, detail='Invalid secret token')
    try:
        update = Update.model_validate(await request.json(), context={'bot': admin_bot})
        await admin_dp.feed_update(admin_bot, update)
        return {'ok': True}
    except Exception as exc:  # noqa: BLE001
        logger.exception('Admin webhook error: %s', exc)
        return {'ok': False}


@app.post('/webhook/client')
async def client_webhook(request: Request, x_telegram_bot_api_secret_token: str = Header(default='')) -> dict[str, bool]:
    if x_telegram_bot_api_secret_token != settings.webhook_secret:
        raise HTTPException(status_code=403, detail='Invalid secret token')
    try:
        update = Update.model_validate(await request.json(), context={'bot': client_bot})
        await client_dp.feed_update(client_bot, update)
        return {'ok': True}
    except Exception as exc:  # noqa: BLE001
        logger.exception('Client webhook error: %s', exc)
        return {'ok': False}


@app.get('/health')
async def health() -> dict[str, str]:
    return {'status': 'ok'}


if __name__ == '__main__':
    uvicorn.run('app.main:app', host='0.0.0.0', port=settings.port, reload=False)
