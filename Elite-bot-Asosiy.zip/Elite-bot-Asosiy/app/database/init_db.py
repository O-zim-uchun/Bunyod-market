from sqlalchemy import text

from app.database.base import Base
from app.database.session import engine
from app.models import app_setting, favorite, order, product, sold_item, user  # noqa: F401


async def _postgres_ensure_schema_updates() -> None:
    statements = [
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS source_chat_id BIGINT",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS source_message_id INTEGER",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS has_video BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS video_chat_id BIGINT",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS video_message_id INTEGER",
        "ALTER TABLE products ALTER COLUMN price SET DEFAULT 0",
        "ALTER TABLE products ALTER COLUMN quantity SET DEFAULT 1",
        "CREATE TABLE IF NOT EXISTS sold_items (id SERIAL PRIMARY KEY, product_name VARCHAR(255) NOT NULL, note TEXT NOT NULL DEFAULT '', sold_price NUMERIC(12,2), sold_at TIMESTAMPTZ NOT NULL DEFAULT now())",
        "CREATE INDEX IF NOT EXISTS ix_sold_items_product_name ON sold_items (product_name)",
        "CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '')",
        "CREATE TABLE IF NOT EXISTS favorites (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE)",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_favorites_user_product ON favorites (user_id, product_id)",
    ]
    async with engine.begin() as conn:
        for stmt in statements:
            await conn.execute(text(stmt))


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    if engine.dialect.name == 'postgresql':
        await _postgres_ensure_schema_updates()
