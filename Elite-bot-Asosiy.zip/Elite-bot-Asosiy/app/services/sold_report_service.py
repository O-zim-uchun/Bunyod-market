import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.product_service import ProductService


class SoldReportService:
    def __init__(self, session: AsyncSession):
        self.session = session

    @staticmethod
    def _json_default(value):
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, Decimal):
            return float(value)
        raise TypeError(f'Unsupported type: {type(value)!r}')

    async def build_monthly_report(self, year: int, month: int) -> Path | None:
        items = await ProductService(self.session).sold_items()
        filtered = [item for item in items if item.sold_at.year == year and item.sold_at.month == month]
        if not filtered:
            return None

        payload = {
            'period': f'{year:04d}-{month:02d}',
            'generated_at': datetime.now(timezone.utc),
            'count': len(filtered),
            'items': [
                {
                    'id': item.id,
                    'product_name': item.product_name,
                    'sold_price': item.sold_price,
                    'note': item.note,
                    'sold_at': item.sold_at,
                }
                for item in filtered
            ],
        }

        target = Path('app/backup/monthly_reports') / f'sold_report_{year:04d}_{month:02d}.json'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=self._json_default), encoding='utf-8')
        return target
