import re
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import Select, delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.favorite import Favorite
from app.models.product import Product
from app.models.sold_item import SoldItem
from app.models.user import User
from app.utils.helpers import category_to_prefix


class ProductService:
    def __init__(self, session: AsyncSession):
        self.session = session

    @staticmethod
    def _newest_first_ordering():
        return Product.created_at.desc(), Product.id.desc()

    @staticmethod
    def parse_name_from_post(text: str | None, fallback: str) -> str:
        if not text:
            return fallback
        for line in text.splitlines():
            m = re.match(r'^\s*Nomi\s*:\s*(.+?)\s*$', line, flags=re.IGNORECASE)
            if m:
                return m.group(1)[:255]
        return text.splitlines()[0][:255] if text.splitlines() else fallback

    async def _next_code(self, category: str) -> str:
        prefix = category_to_prefix(category)
        stmt: Select[tuple[str]] = select(Product.product_id).where(Product.product_id.like(f'{prefix}%')).order_by(Product.id.desc()).limit(1)
        last = await self.session.scalar(stmt)
        if not last:
            return f'{prefix}001'
        number = int(last[len(prefix):]) + 1
        return f'{prefix}{number:03d}'

    async def create_product(self, payload: dict[str, Any]) -> Product:
        product = Product(
            product_id=await self._next_code(payload.get('category', 'stock')),
            name=payload.get('name', 'Tovar'),
            category=payload.get('category', 'stock'),
            price=Decimal(str(payload.get('price', 0))),
            quantity=int(payload.get('quantity', 1)),
            image_url=payload.get('image_url', ''),
            description=payload.get('description', ''),
            is_active=True,
            source_chat_id=payload.get('source_chat_id'),
            source_message_id=payload.get('source_message_id'),
            has_video=bool(payload.get('has_video', False)),
            video_chat_id=payload.get('video_chat_id'),
            video_message_id=payload.get('video_message_id'),
        )
        self.session.add(product)
        await self.session.commit()
        await self.session.refresh(product)
        return product

    async def update_product_from_forward(self, product_id: int, payload: dict[str, Any]) -> Product | None:
        product = await self.get_product(product_id)
        if not product:
            return None
        product.source_chat_id = payload.get('source_chat_id')
        product.source_message_id = payload.get('source_message_id')
        product.name = payload.get('name', product.name)
        product.has_video = bool(payload.get('has_video', False))
        product.video_chat_id = payload.get('video_chat_id')
        product.video_message_id = payload.get('video_message_id')
        await self.session.commit()
        await self.session.refresh(product)
        return product

    async def delete_product(self, product_id: int) -> bool:
        product = await self.get_product(product_id)
        if not product:
            return False
        await self.session.delete(product)
        await self.session.commit()
        return True

    async def list_products(self, category: str | None = None, page: int = 1, page_size: int = 5, active_only: bool = False) -> tuple[list[Product], int]:
        stmt = select(Product)
        count_stmt = select(func.count(Product.id))
        if category:
            stmt = stmt.where(Product.category == category)
            count_stmt = count_stmt.where(Product.category == category)
        if active_only:
            stmt = stmt.where(Product.is_active.is_(True))
            count_stmt = count_stmt.where(Product.is_active.is_(True))
        stmt = stmt.order_by(*self._newest_first_ordering()).offset((page - 1) * page_size).limit(page_size)
        items = list((await self.session.scalars(stmt)).all())
        total = int((await self.session.scalar(count_stmt)) or 0)
        return items, total

    async def get_product(self, product_id: int) -> Product | None:
        return await self.session.get(Product, product_id)

    async def recent_products(self, limit: int = 10) -> list[Product]:
        threshold = datetime.now(timezone.utc) - timedelta(days=10)
        stmt = select(Product).where(Product.is_active.is_(True), Product.created_at >= threshold).order_by(*self._newest_first_ordering()).limit(limit)
        return list((await self.session.scalars(stmt)).all())

    async def recent_products_paginated(self, page: int = 1, page_size: int = 6) -> tuple[list[Product], int]:
        threshold = datetime.now(timezone.utc) - timedelta(days=10)
        stmt = (
            select(Product)
            .where(Product.is_active.is_(True), Product.created_at >= threshold)
            .order_by(*self._newest_first_ordering())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        count_stmt = select(func.count(Product.id)).where(Product.is_active.is_(True), Product.created_at >= threshold)
        items = list((await self.session.scalars(stmt)).all())
        total = int((await self.session.scalar(count_stmt)) or 0)
        return items, total

    async def mark_sold(self, product_id: int, sold_price: float | None = None, note: str = '') -> SoldItem | None:
        product = await self.get_product(product_id)
        if not product:
            return None
        sold = SoldItem(product_name=product.name, sold_price=Decimal(str(sold_price)) if sold_price is not None else None, note=note)
        self.session.add(sold)
        await self.session.commit()
        await self.session.refresh(sold)
        return sold

    async def sold_this_month_count(self) -> int:
        now = datetime.now(timezone.utc)
        start = datetime(now.year, now.month, 1, tzinfo=timezone.utc)
        stmt = select(func.count(SoldItem.id)).where(SoldItem.sold_at >= start)
        return int(await self.session.scalar(stmt) or 0)

    async def sold_items(self) -> list[SoldItem]:
        stmt = select(SoldItem).order_by(SoldItem.sold_at.desc())
        return list((await self.session.scalars(stmt)).all())

    async def clear_sold_items(self) -> int:
        result = await self.session.execute(delete(SoldItem))
        await self.session.commit()
        return int(result.rowcount or 0)

    async def sold_search_exact(self, exact_name: str) -> list[SoldItem]:
        stmt = select(SoldItem).where(func.lower(SoldItem.product_name) == exact_name.lower()).order_by(SoldItem.sold_at.desc())
        return list((await self.session.scalars(stmt)).all())

    async def sold_by_id(self, sold_id: int) -> SoldItem | None:
        return await self.session.get(SoldItem, sold_id)

    async def add_favorite(self, telegram_id: int, product_id: int) -> bool:
        user = await self.session.scalar(select(User).where(User.telegram_id == telegram_id))
        if not user:
            user = User(telegram_id=telegram_id, is_active=True)
            self.session.add(user)
            await self.session.flush()
        existing = await self.session.scalar(select(Favorite).where(Favorite.user_id == user.id, Favorite.product_id == product_id))
        if existing:
            return False
        self.session.add(Favorite(user_id=user.id, product_id=product_id))
        await self.session.commit()
        return True

    async def favorites_for_user(self, telegram_id: int) -> list[Product]:
        stmt = (
            select(Product)
            .join(Favorite, Favorite.product_id == Product.id)
            .join(User, User.id == Favorite.user_id)
            .where(User.telegram_id == telegram_id, Product.is_active.is_(True))
            .order_by(*self._newest_first_ordering())
        )
        return list((await self.session.scalars(stmt)).all())

    async def favorites_for_user_paginated(self, telegram_id: int, page: int = 1, page_size: int = 6) -> tuple[list[Product], int]:
        stmt = (
            select(Product)
            .join(Favorite, Favorite.product_id == Product.id)
            .join(User, User.id == Favorite.user_id)
            .where(User.telegram_id == telegram_id, Product.is_active.is_(True))
            .order_by(*self._newest_first_ordering())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        count_stmt = (
            select(func.count(Product.id))
            .join(Favorite, Favorite.product_id == Product.id)
            .join(User, User.id == Favorite.user_id)
            .where(User.telegram_id == telegram_id, Product.is_active.is_(True))
        )
        items = list((await self.session.scalars(stmt)).all())
        total = int((await self.session.scalar(count_stmt)) or 0)
        return items, total

    async def stats(self) -> dict[str, int]:
        total = int(await self.session.scalar(select(func.count(Product.id))) or 0)
        sold_month = await self.sold_this_month_count()
        return {'total': total, 'sold_month': sold_month}
