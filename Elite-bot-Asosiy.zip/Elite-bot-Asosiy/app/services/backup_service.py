import json
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.app_setting import AppSetting
from app.models.favorite import Favorite
from app.models.order import Order
from app.models.product import Product
from app.models.sold_item import SoldItem
from app.models.user import User


class BackupService:
    def __init__(self, session: AsyncSession, backup_dir: str = 'app/backup'):
        self.session = session
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    async def export_json(self) -> Path:
        products = [self._product_to_dict(p) for p in (await self.session.scalars(select(Product))).all()]
        users = [self._user_to_dict(u) for u in (await self.session.scalars(select(User))).all()]
        orders = [self._order_to_dict(o) for o in (await self.session.scalars(select(Order))).all()]
        sold_items = [self._sold_to_dict(s) for s in (await self.session.scalars(select(SoldItem))).all()]
        settings = [self._setting_to_dict(s) for s in (await self.session.scalars(select(AppSetting))).all()]
        favorites = [self._favorite_to_dict(f) for f in (await self.session.scalars(select(Favorite))).all()]
        payload = {'products': products, 'users': users, 'orders': orders, 'sold_items': sold_items, 'settings': settings, 'favorites': favorites}
        filename = self.backup_dir / f"backup_{datetime.now(timezone.utc).date().isoformat()}_{int(datetime.now(timezone.utc).timestamp())}.json"
        filename.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        self.rotate(keep=10)
        return filename

    def list_backups(self) -> list[Path]:
        return sorted(self.backup_dir.glob('backup_*.json'), reverse=True)

    async def restore(self, backup_path: Path) -> None:
        payload = json.loads(backup_path.read_text(encoding='utf-8'))
        await self.session.execute(delete(Order))
        await self.session.execute(delete(Favorite))
        await self.session.execute(delete(SoldItem))
        await self.session.execute(delete(Product))
        await self.session.execute(delete(AppSetting))
        await self.session.execute(delete(User))

        user_id_map: dict[int, int] = {}
        product_id_map: dict[int, int] = {}

        for item in payload.get('users', []):
            old_id = item.get('id')
            user_kwargs = {
                'telegram_id': item['telegram_id'],
                'is_active': item.get('is_active', True),
            }
            if old_id is not None:
                user_kwargs['id'] = old_id
            user = User(**user_kwargs)
            self.session.add(user)
            await self.session.flush()
            if old_id is not None:
                user_id_map[old_id] = user.id

        for item in payload.get('products', []):
            old_id = item.get('id')
            product_kwargs = dict(item)
            if old_id is None:
                product_kwargs.pop('id', None)
            product = Product(**product_kwargs)
            self.session.add(product)
            await self.session.flush()
            if old_id is not None:
                product_id_map[old_id] = product.id
        await self.session.flush()

        for item in payload.get('sold_items', []):
            sold_kwargs = dict(item)
            if isinstance(sold_kwargs.get('sold_at'), str):
                sold_kwargs['sold_at'] = datetime.fromisoformat(sold_kwargs['sold_at'])
            self.session.add(SoldItem(**sold_kwargs))

        for item in payload.get('settings', []):
            self.session.add(AppSetting(**item))

        existing_user_ids = set((await self.session.scalars(select(User.id))).all())
        existing_product_ids = set((await self.session.scalars(select(Product.id))).all())

        for item in payload.get('orders', []):
            old_user_id = item.get('user_id')
            old_product_id = item.get('product_id')
            user_id = user_id_map.get(old_user_id, old_user_id)
            product_id = product_id_map.get(old_product_id, old_product_id)
            if user_id in existing_user_ids and product_id in existing_product_ids:
                self.session.add(Order(product_id=product_id, user_id=user_id))

        seen_favorites: set[tuple[int, int]] = set()
        for item in payload.get('favorites', []):
            old_user_id = item.get('user_id')
            old_product_id = item.get('product_id')
            user_id = user_id_map.get(old_user_id, old_user_id)
            product_id = product_id_map.get(old_product_id, old_product_id)
            favorite_key = (user_id, product_id)
            if favorite_key in seen_favorites:
                continue
            if user_id in existing_user_ids and product_id in existing_product_ids:
                seen_favorites.add(favorite_key)
                self.session.add(Favorite(user_id=user_id, product_id=product_id))

        await self.session.commit()

    def rotate(self, keep: int = 10) -> None:
        backups = self.list_backups()
        for old in backups[keep:]:
            old.unlink(missing_ok=True)

    @staticmethod
    def _product_to_dict(p: Product) -> dict:
        return {
            'id': p.id,
            'product_id': p.product_id,
            'name': p.name,
            'category': p.category,
            'price': float(p.price),
            'quantity': p.quantity,
            'description': p.description,
            'image_url': p.image_url,
            'is_active': p.is_active,
            'source_chat_id': p.source_chat_id,
            'source_message_id': p.source_message_id,
            'has_video': p.has_video,
            'video_chat_id': p.video_chat_id,
            'video_message_id': p.video_message_id,
        }

    @staticmethod
    def _user_to_dict(u: User) -> dict:
        return {'id': u.id, 'telegram_id': u.telegram_id, 'is_active': u.is_active}

    @staticmethod
    def _order_to_dict(o: Order) -> dict:
        return {'id': o.id, 'user_id': o.user_id, 'product_id': o.product_id}

    @staticmethod
    def _sold_to_dict(s: SoldItem) -> dict:
        return {
            'id': s.id,
            'product_name': s.product_name,
            'note': s.note,
            'sold_price': float(s.sold_price) if s.sold_price is not None else None,
            'sold_at': s.sold_at.isoformat() if s.sold_at else None,
        }

    @staticmethod
    def _setting_to_dict(s: AppSetting) -> dict:
        return {'key': s.key, 'value': s.value}

    @staticmethod
    def _favorite_to_dict(f: Favorite) -> dict:
        return {'id': f.id, 'user_id': f.user_id, 'product_id': f.product_id}
