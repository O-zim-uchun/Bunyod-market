from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User


class UserService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def register(self, telegram_id: int) -> User:
        existing = await self.session.scalar(select(User).where(User.telegram_id == telegram_id))
        if existing:
            return existing
        user = User(telegram_id=telegram_id, is_active=True)
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def all_telegram_ids(self) -> list[int]:
        rows = await self.session.scalars(select(User.telegram_id).where(User.is_active.is_(True)))
        return list(rows)

    async def count_users(self) -> int:
        return int(await self.session.scalar(select(func.count(User.id))) or 0)
