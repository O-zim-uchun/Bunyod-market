import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest

logger = logging.getLogger(__name__)


class BroadcastService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def broadcast(self, user_ids: list[int], text: str, photo: str | None = None) -> None:
        for uid in user_ids:
            try:
                if photo:
                    await self.bot.send_photo(uid, photo=photo, caption=text)
                else:
                    await self.bot.send_message(uid, text)
            except TelegramBadRequest as exc:
                if photo and 'wrong file identifier/HTTP URL specified' in str(exc):
                    try:
                        await self.bot.send_message(uid, text)
                    except Exception as fallback_exc:  # noqa: BLE001
                        logger.warning('Broadcast text fallback failed for %s: %s', uid, fallback_exc)
                else:
                    logger.warning('Broadcast bad request for %s: %s', uid, exc)
            except Exception as exc:  # noqa: BLE001
                logger.warning('Broadcast failed for %s: %s', uid, exc)
