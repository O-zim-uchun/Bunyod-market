import json

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.app_setting import AppSetting


class SettingService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def set_json(self, key: str, value: dict) -> None:
        row = await self.session.get(AppSetting, key)
        payload = json.dumps(value, ensure_ascii=False)
        if row:
            row.value = payload
        else:
            self.session.add(AppSetting(key=key, value=payload))
        await self.session.commit()

    async def get_json(self, key: str) -> dict | None:
        row = await self.session.get(AppSetting, key)
        if not row:
            return None
        try:
            return json.loads(row.value)
        except json.JSONDecodeError:
            return None

    async def all(self) -> list[AppSetting]:
        return list((await self.session.scalars(select(AppSetting))).all())
