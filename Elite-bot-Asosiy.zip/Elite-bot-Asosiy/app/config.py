from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

    admin_bot_token: str = Field(alias='ADMIN_BOT_TOKEN')
    client_bot_token: str = Field(alias='CLIENT_BOT_TOKEN')
    admin_id: int = Field(alias='ADMIN_ID')
    database_url: str = Field(alias='DATABASE_URL')
    redis_url: str | None = Field(default=None, alias='REDIS_URL')
    webhook_base_url: str = Field(alias='WEBHOOK_BASE_URL')
    webhook_secret: str = Field(alias='WEBHOOK_SECRET')
    port: int = Field(default=8000, alias='PORT')


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
