from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, Message

from app.database.session import AsyncSessionLocal
from app.services.product_service import ProductService
from app.services.setting_service import SettingService
from app.services.user_service import UserService
from app.utils.keyboards import client_main_keyboard, product_client_actions, product_list_keyboard

router = Router(name='client_router')
PAGE_SIZE = 6


def _remove_pressed_button_markup(call: CallbackQuery):
    if not call.message or not call.message.reply_markup or not call.data:
        return None
    rows = []
    for row in call.message.reply_markup.inline_keyboard:
        new_row = [btn for btn in row if btn.callback_data != call.data]
        if new_row:
            rows.append(new_row)
    return type(call.message.reply_markup)(inline_keyboard=rows) if rows else None


@router.message(CommandStart())
async def client_start(message: Message) -> None:
    if not message.from_user:
        return
    async with AsyncSessionLocal() as session:
        await UserService(session).register(message.from_user.id)
    await message.answer('Xush kelibsiz! Kerakli bo‘limni tanlang.', reply_markup=client_main_keyboard())


@router.message(F.text == '🛍 Tovarlar')
async def tovarlar(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        products, total = await ProductService(session).list_products(page=1, page_size=PAGE_SIZE, active_only=True)
    if not products:
        await message.answer('Hozircha mahsulotlar mavjud emas.')
        return
    kb = product_list_keyboard([p.id for p in products], [p.name for p in products], 0, False, total > PAGE_SIZE, 'client_list:all')
    await message.answer('Tovarlar ro‘yxati:', reply_markup=kb)


@router.message(F.text == '🔥 Yangi kelganlar')
async def new_items(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        products, total = await ProductService(session).recent_products_paginated(page=1, page_size=PAGE_SIZE)
    if not products:
        await message.answer('Yangi mahsulotlar yo‘q.')
        return
    kb = product_list_keyboard([p.id for p in products], [p.name for p in products], 0, False, total > PAGE_SIZE, 'new_list')
    await message.answer('Yangi kelganlar ro‘yxati:', reply_markup=kb)


@router.message(F.text == '❤️ Sevimlilar ro‘yxati')
async def favorites(message: Message) -> None:
    if not message.from_user:
        return
    async with AsyncSessionLocal() as session:
        products, total = await ProductService(session).favorites_for_user_paginated(message.from_user.id, page=1, page_size=PAGE_SIZE)
    if not products:
        await message.answer('Sevimli tovarlar yo‘q.')
        return
    kb = product_list_keyboard([p.id for p in products], [p.name for p in products], 0, False, total > PAGE_SIZE, 'fav_list')
    await message.answer('Sevimli tovarlar:', reply_markup=kb)


@router.callback_query(F.data.startswith('client_list:all:'))
@router.callback_query(F.data.startswith('new_list:'))
@router.callback_query(F.data.startswith('fav_list:'))
async def any_list_nav(call: CallbackQuery) -> None:
    parts = call.data.split(':')
    action = parts[-2]
    value = parts[-1]
    list_prefix = ':'.join(parts[:-2])

    if action == 'view':
        pid = int(value)
        async with AsyncSessionLocal() as session:
            product = await ProductService(session).get_product(pid)
        if not product:
            await call.answer('Topilmadi', show_alert=True)
            return
        await call.bot.copy_message(
            chat_id=call.message.chat.id,
            from_chat_id=product.source_chat_id,
            message_id=product.source_message_id,
            reply_markup=product_client_actions(product.id, product.has_video),
        )
        await call.answer()
        return

    await call.answer()


@router.callback_query(F.data.regexp(r'^page_\d+$'))
async def list_pagination(call: CallbackQuery) -> None:
    if not call.message:
        await call.answer()
        return
    page = int(call.data.split('_')[-1])
    text = call.message.text or ''

    async with AsyncSessionLocal() as session:
        if text == 'Tovarlar ro‘yxati:':
            products, total = await ProductService(session).list_products(page=page + 1, page_size=PAGE_SIZE, active_only=True)
            prefix = 'client_list:all'
        elif text == 'Yangi kelganlar ro‘yxati:':
            products, total = await ProductService(session).recent_products_paginated(page=page + 1, page_size=PAGE_SIZE)
            prefix = 'new_list'
        elif text == 'Sevimli tovarlar:':
            if not call.from_user:
                await call.answer('Xatolik', show_alert=True)
                return
            products, total = await ProductService(session).favorites_for_user_paginated(call.from_user.id, page=page + 1, page_size=PAGE_SIZE)
            prefix = 'fav_list'
        else:
            await call.answer()
            return

    has_prev = page > 0
    has_next = total > (page + 1) * PAGE_SIZE
    kb = product_list_keyboard([p.id for p in products], [p.name for p in products], page, has_prev, has_next, prefix)
    await call.message.edit_text(text, reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith('client_video:'))
async def client_video(call: CallbackQuery) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    pid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        product = await ProductService(session).get_product(pid)
    if not product or not product.has_video:
        await call.answer('Video yo‘q', show_alert=True)
        return
    await call.bot.copy_message(chat_id=call.message.chat.id, from_chat_id=product.video_chat_id, message_id=product.video_message_id)
    await call.answer()


@router.callback_query(F.data.startswith('fav_add:'))
async def fav_add(call: CallbackQuery) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    if not call.from_user:
        await call.answer('Xatolik', show_alert=True)
        return
    pid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        added = await ProductService(session).add_favorite(call.from_user.id, pid)
    await call.answer('Sevimlilarga qo‘shildi' if added else 'Avval qo‘shilgan', show_alert=True)


@router.message(F.text == '💰 Aksiya')
async def promo(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        post = await SettingService(session).get_json('promo_post')
    if not post:
        await message.answer('Aksiya mavjud emas.')
        return
    await message.bot.copy_message(chat_id=message.chat.id, from_chat_id=post['chat_id'], message_id=post['message_id'])


@router.message(F.text == '📞 Aloqa')
async def contact(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        post = await SettingService(session).get_json('contact_post')
    if not post:
        await message.answer('Aloqa maʼlumoti mavjud emas.')
        return
    await message.bot.copy_message(chat_id=message.chat.id, from_chat_id=post['chat_id'], message_id=post['message_id'])


@router.message()
async def fallback(message: Message) -> None:
    await message.answer('Noto‘g‘ri buyruq. Tugmalardan foydalaning.', reply_markup=client_main_keyboard())
