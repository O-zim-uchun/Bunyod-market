from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.bot_client.handlers.client import router as client_router
from app.config import get_settings

settings = get_settings()

client_bot = Bot(token=settings.client_bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
client_dp = Dispatcher()
client_dp.include_router(client_router)
