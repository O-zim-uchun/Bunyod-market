from datetime import datetime

from sqlalchemy import DateTime, Integer, Numeric, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class SoldItem(Base):
    __tablename__ = 'sold_items'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    note: Mapped[str] = mapped_column(Text, default='', nullable=False)
    sold_price: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)
    sold_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
