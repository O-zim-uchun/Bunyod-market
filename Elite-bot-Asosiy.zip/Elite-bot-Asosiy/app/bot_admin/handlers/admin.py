from datetime import datetime, timezone
from pathlib import Path

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message

from app.config import get_settings
from app.database.session import AsyncSessionLocal
from app.services.backup_service import BackupService
from app.services.broadcast_service import BroadcastService
from app.services.product_service import ProductService
from app.services.setting_service import SettingService
from app.services.user_service import UserService
from app.utils.fsm_states import AddProductState, BroadcastState, EditProductState, RestoreState, SettingsPostState, SoldProductState, SoldSearchState
from app.utils.keyboards import (
    BACK_TEXT,
    admin_main_keyboard,
    back_keyboard,
    no_video_keyboard,
    product_admin_actions,
    product_list_keyboard,
    settings_keyboard,
    sold_menu_keyboard,
    sold_search_pick_keyboard,
    sold_skip_keyboard,
)

router = Router(name='admin_router')
settings = get_settings()


def _extract_forward_ref(message: Message) -> tuple[int, int] | None:
    if message.forward_from_chat and message.forward_from_message_id:
        return message.forward_from_chat.id, message.forward_from_message_id
    return None


async def _is_admin(message: Message) -> bool:
    return bool(message.from_user and message.from_user.id == settings.admin_id)


def _remove_pressed_button_markup(call: CallbackQuery):
    if not call.message or not call.message.reply_markup or not call.data:
        return None
    rows = []
    for row in call.message.reply_markup.inline_keyboard:
        new_row = [btn for btn in row if btn.callback_data != call.data]
        if new_row:
            rows.append(new_row)
    return type(call.message.reply_markup)(inline_keyboard=rows) if rows else None


@router.message(CommandStart())
async def admin_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    if not await _is_admin(message):
        await message.answer('Siz admin emassiz.')
        return
    await message.answer('Admin panelga xush kelibsiz.', reply_markup=admin_main_keyboard())


@router.message(F.text == BACK_TEXT)
async def universal_back(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer('Asosiy menyu.', reply_markup=admin_main_keyboard())


@router.message(F.text == '❌Bekor qilish')
async def cancel_current(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer('Joriy jarayon bekor qilindi.', reply_markup=admin_main_keyboard())


@router.message(F.text == '➕ Yangi tovar qo‘shish')
async def add_product_begin(message: Message, state: FSMContext) -> None:
    await state.set_state(AddProductState.waiting_post)
    await message.answer('Kanal postini botga forward qiling.', reply_markup=back_keyboard())


@router.message(AddProductState.waiting_post)
async def add_product_forward(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Iltimos, kanal postini forward qiling.')
        return
    full_text = message.caption or message.text or ''
    name = ProductService.parse_name_from_post(full_text, f'Tovar {ref[1]}')
    await state.update_data(source_chat_id=ref[0], source_message_id=ref[1], name=name)
    await state.set_state(AddProductState.waiting_video_or_skip)
    await message.answer("Qabul qilindi video qo'shasizmi?", reply_markup=no_video_keyboard('add_video'))


@router.callback_query(F.data == 'add_video:no')
async def add_video_no(call: CallbackQuery, state: FSMContext) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    data = await state.get_data()
    async with AsyncSessionLocal() as session:
        await ProductService(session).create_product(
            {
                'name': data.get('name', 'Tovar'),
                'category': 'stock',
                'price': 0,
                'quantity': 1,
                'description': '',
                'source_chat_id': data.get('source_chat_id'),
                'source_message_id': data.get('source_message_id'),
                'has_video': False,
            },
        )
    await state.clear()
    await call.message.answer('Saqlandi', reply_markup=admin_main_keyboard())
    await call.answer()


@router.message(AddProductState.waiting_video_or_skip)
async def add_video_auto(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Video yuborsangiz avtomatik saqlanadi yoki "Yo‘q" tugmasini bosing.')
        return
    data = await state.get_data()
    async with AsyncSessionLocal() as session:
        await ProductService(session).create_product(
            {
                'name': data.get('name', 'Tovar'),
                'category': 'stock',
                'price': 0,
                'quantity': 1,
                'description': '',
                'source_chat_id': data.get('source_chat_id'),
                'source_message_id': data.get('source_message_id'),
                'has_video': True,
                'video_chat_id': ref[0],
                'video_message_id': ref[1],
            },
        )
    await state.clear()
    await message.answer('Saqlandi', reply_markup=admin_main_keyboard())


@router.message(F.text == '📦 Ombor')
async def stock_view(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        products, total = await ProductService(session).list_products(page=1, page_size=6)
    if not products:
        await message.answer('Ombor bo‘sh.')
        return
    kb = product_list_keyboard([p.id for p in products], [f'{p.product_id} | {p.name}' for p in products], 0, False, total > 6, 'stock')
    await message.answer('Ombordagi mahsulotlar:', reply_markup=kb)


@router.callback_query(F.data.regexp(r'^page_\d+$'))
async def stock_pagination(call: CallbackQuery) -> None:
    if not call.message or call.message.text != 'Ombordagi mahsulotlar:':
        await call.answer()
        return
    page = int(call.data.split('_')[-1])
    async with AsyncSessionLocal() as session:
        products, total = await ProductService(session).list_products(page=page + 1, page_size=6)
    has_prev = page > 0
    has_next = total > (page + 1) * 6
    kb = product_list_keyboard([p.id for p in products], [f'{p.product_id} | {p.name}' for p in products], page, has_prev, has_next, 'stock')
    await call.message.edit_text('Ombordagi mahsulotlar:', reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith('stock:view:'))
async def stock_detail(call: CallbackQuery) -> None:
    pid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        product = await ProductService(session).get_product(pid)
    if not product:
        await call.answer('Topilmadi', show_alert=True)
        return
    await call.bot.copy_message(chat_id=call.message.chat.id, from_chat_id=product.source_chat_id, message_id=product.source_message_id)
    await call.message.answer('Boshqaruv:', reply_markup=product_admin_actions(product.id, product.has_video))
    await call.answer()


@router.callback_query(F.data.startswith('admin_video:'))
async def admin_video(call: CallbackQuery) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    pid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        product = await ProductService(session).get_product(pid)
    if not product or not product.has_video:
        await call.answer('Video yo‘q', show_alert=True)
        return
    await call.bot.copy_message(chat_id=call.message.chat.id, from_chat_id=product.video_chat_id, message_id=product.video_message_id)
    await call.answer()


@router.callback_query(F.data.startswith('admin_edit:'))
async def admin_edit_start(call: CallbackQuery, state: FSMContext) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    pid = int(call.data.split(':')[-1])
    await state.update_data(edit_product_id=pid)
    await state.set_state(EditProductState.waiting_post)
    await call.message.answer('Yangi postni kanaldan forward qiling.')
    await call.answer()


@router.message(EditProductState.waiting_post)
async def admin_edit_post(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Iltimos, postni forward qiling.')
        return
    name = ProductService.parse_name_from_post(message.caption or message.text or '', f'Tovar {ref[1]}')
    await state.update_data(source_chat_id=ref[0], source_message_id=ref[1], name=name)
    await state.set_state(EditProductState.waiting_video_or_skip)
    await message.answer("Qabul qilindi video qo'shasizmi?", reply_markup=no_video_keyboard('edit_video'))


@router.callback_query(F.data == 'edit_video:no')
async def edit_video_no(call: CallbackQuery, state: FSMContext) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    data = await state.get_data()
    async with AsyncSessionLocal() as session:
        await ProductService(session).update_product_from_forward(
            data['edit_product_id'],
            {
                'name': data.get('name'),
                'source_chat_id': data.get('source_chat_id'),
                'source_message_id': data.get('source_message_id'),
                'has_video': False,
                'video_chat_id': None,
                'video_message_id': None,
            },
        )
    await state.clear()
    await call.message.answer('Tahrirlandi', reply_markup=admin_main_keyboard())
    await call.answer()


@router.message(EditProductState.waiting_video_or_skip)
async def edit_video_auto(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Video yuborsangiz avtomatik tahrirlanadi yoki "Yo‘q" tugmasini bosing.')
        return
    data = await state.get_data()
    async with AsyncSessionLocal() as session:
        await ProductService(session).update_product_from_forward(
            data['edit_product_id'],
            {
                'name': data.get('name'),
                'source_chat_id': data.get('source_chat_id'),
                'source_message_id': data.get('source_message_id'),
                'has_video': True,
                'video_chat_id': ref[0],
                'video_message_id': ref[1],
            },
        )
    await state.clear()
    await message.answer('Tahrirlandi', reply_markup=admin_main_keyboard())


@router.callback_query(F.data.startswith('admin_delete:'))
async def admin_delete(call: CallbackQuery) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    pid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        deleted = await ProductService(session).delete_product(pid)
    await call.answer('O‘chirildi' if deleted else 'Topilmadi', show_alert=True)


@router.callback_query(F.data.startswith('admin_sold:'))
async def sold_start(call: CallbackQuery, state: FSMContext) -> None:
    pid = int(call.data.split(':')[-1])
    await state.update_data(sold_product_id=pid)
    await state.set_state(SoldProductState.waiting_price)
    await call.message.answer('Narxni yuboring', reply_markup=sold_skip_keyboard())
    await call.answer()


@router.callback_query(F.data == 'sold_skip')
async def sold_skip(call: CallbackQuery, state: FSMContext) -> None:
    if call.message:
        await call.message.edit_reply_markup(reply_markup=_remove_pressed_button_markup(call))
    current = await state.get_state()
    if current == SoldProductState.waiting_price.state:
        await state.update_data(sold_price=None)
        await state.set_state(SoldProductState.waiting_note)
        await call.message.answer('Biror gap ilova qilasizmi?', reply_markup=sold_skip_keyboard())
    else:
        await _finalize_sold(call.message, state, note='')
    await call.answer()


@router.message(SoldProductState.waiting_price)
async def sold_price(message: Message, state: FSMContext) -> None:
    try:
        price = float((message.text or '').replace(' ', ''))
    except ValueError:
        await message.answer('Narx noto‘g‘ri. Qayta yuboring yoki o‘tkazib yuboring.')
        return
    await state.update_data(sold_price=price)
    await state.set_state(SoldProductState.waiting_note)
    await message.answer('Biror gap ilova qilasizmi?', reply_markup=sold_skip_keyboard())


@router.message(SoldProductState.waiting_note)
async def sold_note(message: Message, state: FSMContext) -> None:
    await _finalize_sold(message, state, note=message.text or '')


async def _finalize_sold(message: Message, state: FSMContext, note: str) -> None:
    data = await state.get_data()
    async with AsyncSessionLocal() as session:
        sold = await ProductService(session).mark_sold(data['sold_product_id'], sold_price=data.get('sold_price'), note=note)
    await state.clear()
    if not sold:
        await message.answer('Tovar topilmadi.', reply_markup=admin_main_keyboard())
        return
    when = sold.sold_at.astimezone(timezone.utc).strftime('%d %B %Y. %H:%M')
    await message.answer(
        f"Tovar nomi: {sold.product_name}\nIlova: {sold.note or '-'}\nSotildi: {int(sold.sold_price) if sold.sold_price is not None else '-'} so'm\nSotilgan vaqti: {when}",
        reply_markup=admin_main_keyboard(),
    )


@router.message(F.text == '📊 Statistika')
async def stats(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        ps = await ProductService(session).stats()
        users = await UserService(session).count_users()
    await message.answer(f"Mavjud tovarlar soni: {ps['total']}\nBu oyda sotilganlar: {ps['sold_month']}\nFoydalanuvchilar soni: {users}")


@router.message(F.text == '📤Mijozga xabar')
async def broadcast_start(message: Message, state: FSMContext) -> None:
    await state.set_state(BroadcastState.waiting_message)
    await message.answer('Mijozlarga yuboriladigan xabarni yuboring.', reply_markup=back_keyboard())


@router.message(BroadcastState.waiting_message)
async def broadcast_send(message: Message, state: FSMContext, client_bot) -> None:
    async with AsyncSessionLocal() as session:
        users = await UserService(session).all_telegram_ids()
    if message.photo:
        await BroadcastService(client_bot).broadcast(users, text=message.caption or '', photo=message.photo[-1].file_id)
    else:
        await BroadcastService(client_bot).broadcast(users, text=message.text or '')
    await state.clear()
    await message.answer('Yuborildi.', reply_markup=admin_main_keyboard())


@router.message(F.text == '💵 Sotilganlar')
async def sold_menu(message: Message) -> None:
    await message.answer('Sotilganlar bo‘limi.', reply_markup=sold_menu_keyboard())


@router.message(F.text.regexp(r"(?i)ro['‘’]?yxatni\s+yuklash"))
async def sold_export(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        items = await ProductService(session).sold_items()
    out = Path('app/backup/sold_items.exe')
    out.parent.mkdir(parents=True, exist_ok=True)
    total_month = 0
    now = datetime.now(timezone.utc)
    lines = []
    for idx, item in enumerate(items, start=1):
        lines.append(f"{idx}. {item.product_name} | {item.sold_price or '-'} | {item.note or '-'} | {item.sold_at}")
        if item.sold_price is not None and item.sold_at.year == now.year and item.sold_at.month == now.month:
            total_month += int(item.sold_price)
    lines.append('')
    lines.append(f"Bu oydagi jami sotilgan tovarlar summasi: {total_month} so'm")
    out.write_text('\n'.join(lines), encoding='utf-8')
    await message.answer_document(FSInputFile(out.as_posix()), caption='Sotilganlar ro‘yxati')


@router.message(F.text == 'Izlash')
async def sold_search_start(message: Message, state: FSMContext) -> None:
    await state.set_state(SoldSearchState.waiting_query)
    await message.answer('Tovar nomini kiriting:')


@router.message(SoldSearchState.waiting_query)
async def sold_search(message: Message, state: FSMContext) -> None:
    query = (message.text or '').strip()
    async with AsyncSessionLocal() as session:
        rows = await ProductService(session).sold_search_exact(query)
    await state.clear()
    if not rows:
        await message.answer('Topilmadi.', reply_markup=sold_menu_keyboard())
        return
    if len(rows) == 1:
        item = rows[0]
        when = item.sold_at.astimezone(timezone.utc).strftime('%d %B %Y. %H:%M')
        await message.answer(
            f"Tovar nomi: {item.product_name}\nIlova: {item.note or '-'}\nSotildi: {int(item.sold_price) if item.sold_price is not None else '-'} so'm\nSotilgan vaqti: {when}",
            reply_markup=sold_menu_keyboard(),
        )
        return
    kb = sold_search_pick_keyboard([r.id for r in rows], [r.sold_at.astimezone(timezone.utc).strftime('%d.%m.%Y %H:%M') for r in rows])
    await message.answer('Bir xil nomli yozuvlar topildi, bittasini tanlang:', reply_markup=kb)


@router.callback_query(F.data.startswith('sold_pick:'))
async def sold_pick(call: CallbackQuery) -> None:
    sid = int(call.data.split(':')[-1])
    async with AsyncSessionLocal() as session:
        item = await ProductService(session).sold_by_id(sid)
    if not item:
        await call.answer('Topilmadi', show_alert=True)
        return
    when = item.sold_at.astimezone(timezone.utc).strftime('%d %B %Y. %H:%M')
    await call.message.answer(
        f"Tovar nomi: {item.product_name}\nIlova: {item.note or '-'}\nSotildi: {int(item.sold_price) if item.sold_price is not None else '-'} so'm\nSotilgan vaqti: {when}",
    )
    await call.answer()


@router.message(F.text == '⚙️Sozlash')
async def settings_menu(message: Message) -> None:
    await message.answer('Sozlash bo‘limi.', reply_markup=settings_keyboard())


@router.message(F.text == '💰 Aksiya')
async def settings_promo(message: Message, state: FSMContext) -> None:
    await state.set_state(SettingsPostState.waiting_promo_post)
    await message.answer('Aksiya postini kanaldan forward qiling.')


@router.message(F.text == '📞Aloqa')
async def settings_contact(message: Message, state: FSMContext) -> None:
    await state.set_state(SettingsPostState.waiting_contact_post)
    await message.answer('Aloqa postini kanaldan forward qiling.')


@router.message(SettingsPostState.waiting_promo_post)
async def save_promo(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Postni forward qiling.')
        return
    async with AsyncSessionLocal() as session:
        await SettingService(session).set_json('promo_post', {'chat_id': ref[0], 'message_id': ref[1]})
    await state.clear()
    await message.answer('Aksiya yangilandi.', reply_markup=admin_main_keyboard())


@router.message(SettingsPostState.waiting_contact_post)
async def save_contact(message: Message, state: FSMContext) -> None:
    ref = _extract_forward_ref(message)
    if not ref:
        await message.answer('Postni forward qiling.')
        return
    async with AsyncSessionLocal() as session:
        await SettingService(session).set_json('contact_post', {'chat_id': ref[0], 'message_id': ref[1]})
    await state.clear()
    await message.answer('Aloqa yangilandi.', reply_markup=admin_main_keyboard())


@router.message(F.text == '💾 Backup olish')
async def backup_now(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        path = await BackupService(session).export_json()
    await message.answer_document(document=FSInputFile(path.as_posix()), caption=f'Backup yaratildi: {path.name}')


@router.message(F.text == '♻️ Restore qilish')
async def restore_menu(message: Message, state: FSMContext) -> None:
    await state.set_state(RestoreState.waiting_file)
    await message.answer('Backup faylni yuboring (json).', reply_markup=back_keyboard())


@router.message(RestoreState.waiting_file, F.document)
async def restore_from_uploaded_file(message: Message, state: FSMContext) -> None:
    if not message.document:
        await message.answer('Backup faylni yuboring.')
        return
    filename = (message.document.file_name or '').lower()
    if not filename.endswith('.json'):
        await message.answer('Faqat .json backup fayl yuboring.')
        return

    target = Path('app/backup') / f'uploaded_restore_{message.document.file_unique_id}.json'
    target.parent.mkdir(parents=True, exist_ok=True)

    file = await message.bot.get_file(message.document.file_id)
    await message.bot.download_file(file.file_path, destination=target.as_posix())

    async with AsyncSessionLocal() as session:
        await BackupService(session).restore(target)

    await state.clear()
    await message.answer('Restore bajarildi.', reply_markup=admin_main_keyboard())


@router.message(RestoreState.waiting_file)
async def restore_waiting_invalid(message: Message) -> None:
    await message.answer('Iltimos, backup json faylni yuboring.')


@router.message()
async def fallback(message: Message) -> None:
    await message.answer('Tugmalardan foydalaning.', reply_markup=admin_main_keyboard())
