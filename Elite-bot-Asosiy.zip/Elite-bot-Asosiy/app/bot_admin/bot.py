from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.bot_admin.handlers.admin import router as admin_router
from app.config import get_settings

settings = get_settings()

admin_bot = Bot(token=settings.admin_bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
admin_dp = Dispatcher()
admin_dp.include_router(admin_router)
